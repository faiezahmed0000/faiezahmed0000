import * as Scrivito from "scrivito";
import pricingSpecWidgetIcon from "../../assets/images/pricing_spec_widget.svg";

Scrivito.provideEditingConfig("PricingSpecWidget", {
  title: "Pricing Spec",
  thumbnail: pricingSpecWidgetIcon,
});
