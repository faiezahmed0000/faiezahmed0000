import * as Scrivito from "scrivito";
import groupWidgetIcon from "../../assets/images/group_widget.svg";

Scrivito.provideEditingConfig("GroupWidget", {
  title: "Group",
  thumbnail: groupWidgetIcon,
});
