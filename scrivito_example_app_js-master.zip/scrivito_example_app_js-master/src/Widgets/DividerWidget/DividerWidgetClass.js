import * as Scrivito from "scrivito";

const DividerWidget = Scrivito.provideWidgetClass("DividerWidget", {
  attributes: {
    showLogo: "boolean",
  },
});

export default DividerWidget;
