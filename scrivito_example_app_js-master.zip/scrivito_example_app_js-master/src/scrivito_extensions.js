import "./Objs";
import "./Objs/editingConfigs";
import "./Widgets";
import "./Widgets/editingConfigs";
import { configure } from "./config";
import "./Components/ScrivitoExtensions";
import "./assets/stylesheets/index.scss";

configure();
