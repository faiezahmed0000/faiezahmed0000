import * as Scrivito from "scrivito";

const RedirectToUi = Scrivito.provideObjClass("RedirectToUi", {
  attributes: {},
});

export default RedirectToUi;
