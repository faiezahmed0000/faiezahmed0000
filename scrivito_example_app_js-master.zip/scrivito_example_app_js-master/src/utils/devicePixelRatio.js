function devicePixelRatio() {
  return window.devicePixelRatio || 1;
}

export default devicePixelRatio;
