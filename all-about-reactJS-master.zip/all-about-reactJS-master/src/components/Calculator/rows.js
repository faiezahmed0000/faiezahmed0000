export const rows = [
    [{ flex: 1, buttonContent: 'AC', position: 'top' }, { flex: 1, buttonContent: 'DEL', position: 'top' }, { flex: 1, buttonContent: '%', position: 'top' }, { flex: 1, buttonContent: '÷', position: 'right' }],
    [{ flex: 1, buttonContent: '7', position: 'center' }, { flex: 1, buttonContent: '8', position: 'center' }, { flex: 1, buttonContent: '9', position: 'center' }, { flex: 1, buttonContent: '×', position: 'right' }],
    [{ flex: 1, buttonContent: '4', position: 'center' }, { flex: 1, buttonContent: '5', position: 'center' }, { flex: 1, buttonContent: '6', position: 'center' }, { flex: 1, buttonContent: '-', position: 'right' }],
    [{ flex: 1, buttonContent: '1', position: 'center' }, { flex: 1, buttonContent: '2', position: 'center' }, { flex: 1, buttonContent: '3', position: 'center' }, { flex: 1, buttonContent: '+', position: 'right' }],
    [{ flex: '2 1 11%', buttonContent: '0', position: 'center' }, { flex: 1, buttonContent: '.', position: 'center' }, { flex: 1, buttonContent: '=', position: 'right' }],
];