# React with three.js example

See the [demo](https://willbamford.github.io/react-with-threejs-example/)

Created in response to [this question](https://stackoverflow.com/questions/41248287/how-to-connect-threejs-to-react) on Stack Overflow.

## Using React Hooks

Take a look at [`VisWithHooks.jsx`](src/VisWithHooks.jsx) for the same example implemented using [React Hooks](https://reactjs.org/docs/hooks-overview.html).
