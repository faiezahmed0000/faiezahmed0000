import React from 'react'

// import Vis from './VisWithClass'
import Vis from './VisWithHooks'

const App = () => (
  <div className="app">
    <Vis />
  </div>
)

export default App
