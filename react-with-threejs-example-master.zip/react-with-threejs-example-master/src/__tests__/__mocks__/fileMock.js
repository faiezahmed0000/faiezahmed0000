export default 'file-mock'
