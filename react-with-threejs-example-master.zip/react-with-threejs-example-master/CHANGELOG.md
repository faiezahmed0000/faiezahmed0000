## v1.2.0

- Added Jest integration
- Added support for `async` / `await`

## v1.1.0

- Upgrade to Babel 7 (using `npx babel-upgrade --write`)
