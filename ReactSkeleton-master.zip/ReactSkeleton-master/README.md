# React Skeleton

This is a simple project that is used to initialize my own react.js projects. It includes most important libraries to start on the right way,

You can use it, just clone this repository
```
git clone https://github.com/juanortiz10/ReactSkeleton.git
```

Then you should initialize npm to download all required dependencies:
```
npm init
npm install
```


### Notes
This skeleton is working with node express server

To init express server you have to call it, with next sentence:
```
npm run dev
```

Watchify is used to listen to new changes, also you have to keep your npm initialized like this:
```
npm start
```

License
----

Apache
