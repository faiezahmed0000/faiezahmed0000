var React = require('react');

var Index = React.createClass({
  render: function(){
    return(
      <div>Hi I'm the index</div>
    );
  }
});

module.exports = Index;
