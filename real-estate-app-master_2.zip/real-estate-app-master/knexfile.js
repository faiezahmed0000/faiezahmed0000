/*eslint strict:0 */
'use strict';
let config = require('./lib/config');

module.exports = config.database;
