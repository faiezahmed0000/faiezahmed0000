import React from 'react';

export default React.createClass({
	render() {
		return (
			<div className="footer">
				<p className="footerText">©2017 Dan Buda</p>
			</div>
			);
	}
});