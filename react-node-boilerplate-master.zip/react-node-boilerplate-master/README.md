# A React Js and Node Js Boilerplate
## Installation Instructions

Install nodemon and create-react-app globally using below command:

`$ npm i -D nodemon`

`npm i -g create-react-app`

Installation Instructions 🔧
Clone the repo using git clone git@github.com:imranhsayed/react-node-boilerplate.git
```cd google-maps-in-react
npm install
cd client
npm install
cd ..
npm run dev
