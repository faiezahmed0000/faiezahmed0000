const mock = {}
export default mock
