export const readAsStringAsync = async () => new Promise((res) => res(''))
