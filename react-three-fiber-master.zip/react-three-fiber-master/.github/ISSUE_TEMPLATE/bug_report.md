---
name: Bug report
about: Create a report to help us improve
title: ''
labels: ''
assignees: ''
---

👋 hi there, for issues that aren't that pressing, that could be related to threejs etc, please consider [github discussions](https://github.com/pmndrs/react-three-fiber/discussions).
