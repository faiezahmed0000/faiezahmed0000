# example

## 1.0.0

### Major Changes

- 385ba9c: v8 major, react-18 compat
- 04c07b8: v8 major, react-18 compat

## 1.0.0-beta.0

### Major Changes

- 385ba9c: v8 major, react-18 compat
