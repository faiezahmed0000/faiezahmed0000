export default class DateTime extends React.Component {

    render() {
        return React.createElement('time', null, 'Date/Time');
    }

}