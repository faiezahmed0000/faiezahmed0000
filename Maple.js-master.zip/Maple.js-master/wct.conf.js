module.exports = {
    verbose: false,
    suites: ['tests/*.html'],
    plugins: {
        local: {
            browsers: ['chrome']
        }
    }
};