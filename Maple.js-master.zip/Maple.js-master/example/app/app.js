(function main($window) {

    "use strict";

    $window.app = { alt: new Alt(), actions: {}, stores: {} };

})(window);