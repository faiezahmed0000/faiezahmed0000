import * as Core from '@vercel/commerce/types/checkout'

export type CheckoutTypes = Core.CheckoutTypes
export type CheckoutSchema = Core.CheckoutSchema<CheckoutTypes>
