export default function noopApi(...args: any[]): void {}
